CREATE VIEW video_db.director_info AS
  SELECT
    `video_db`.`director`.`Director_ID`        AS `Director_ID`,
    `video_db`.`director`.`Director_Name`      AS `Director_Name`,
    `video_db`.`director`.`Director_Nation`    AS `Director_Nation`,
    `video_db`.`director`.`Director_Birthday`  AS `Director_Birthday`,
    `video_db`.`director`.`Director_MainAward` AS `Director_MainAward`
  FROM `video_db`.`director`;
