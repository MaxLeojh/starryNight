CREATE VIEW video_db.video_type_view AS
  SELECT
    `video_db`.`video_type`.`Video_ID` AS `Video_ID`,
    `video_db`.`type`.`Type_Name`      AS `Type_Name`
  FROM (`video_db`.`video_type`
    JOIN `video_db`.`type`)
  WHERE (`video_db`.`video_type`.`Type_ID` = `video_db`.`type`.`Type_ID`);
