CREATE VIEW video_db.video_complete AS
  SELECT
    `video_db`.`video`.`Video_ID`           AS `Video_ID`,
    `video_db`.`video`.`Director_ID`        AS `Director_ID`,
    `video_db`.`video`.`Admin_ID`           AS `Admin_ID`,
    `video_db`.`video`.`Video_Name`         AS `Video_Name`,
    `video_db`.`video`.`Video_Info`         AS `Video_Info`,
    `video_db`.`video`.`Video_Date`         AS `Video_Date`,
    `video_db`.`video`.`Video_Time`         AS `Video_Time`,
    `video_db`.`video`.`Video_Score`        AS `Video_Score`,
    `video_db`.`video`.`Video_ScriptWriter` AS `Video_ScriptWriter`,
    `video_db`.`video`.`Video_Nation`       AS `Video_Nation`,
    `video_db`.`video`.`Video_MainAward`    AS `Video_MainAward`,
    `video_db`.`video`.`Video_ForeignName`  AS `Video_ForeignName`,
    `video_db`.`video`.`Video_Address`      AS `Video_Address`,
    `video_db`.`type`.`Type_Name`           AS `Type_Name`,
    `video_db`.`actor`.`Actor_Name`         AS `Actor_Name`,
    `video_db`.`director`.`Director_Name`   AS `Director_Name`
  FROM (((((`video_db`.`actor`
    JOIN `video_db`.`director`) JOIN `video_db`.`participating`) JOIN `video_db`.`type`) JOIN `video_db`.`video`) JOIN
    `video_db`.`video_type`)
  WHERE ((`video_db`.`actor`.`Actor_ID` = `video_db`.`participating`.`Actor_ID`) AND
         (`video_db`.`participating`.`Video_ID` = `video_db`.`video`.`Video_ID`) AND
         (`video_db`.`director`.`Director_ID` = `video_db`.`video`.`Director_ID`) AND
         (`video_db`.`video_type`.`Video_ID` = `video_db`.`video`.`Video_ID`) AND
         (`video_db`.`video_type`.`Type_ID` = `video_db`.`type`.`Type_ID`));
